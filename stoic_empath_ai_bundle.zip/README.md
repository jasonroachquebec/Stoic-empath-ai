# Stoic Empath AI

Prototype landing page + pitch deck for Freya Mortensen.

## Deploy
Upload files to GitHub repo and enable GitHub Pages.
